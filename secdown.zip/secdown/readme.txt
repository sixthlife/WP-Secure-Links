Icon by http://www.doublejdesign.co.uk/ under following licence

https://creativecommons.org/licenses/by/3.0/